#ifndef MAXCLIQUEDEF
#define MAXCLIQUEDEF

#include "colorrtns.h"

extern int maxclique( popmembertype *m);

#endif
