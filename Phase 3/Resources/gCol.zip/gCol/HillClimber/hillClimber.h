#ifndef hillClimber_H
#define hillClimber_H

#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <list>
#include <time.h>
#include <math.h>
#include <stdio.h>
#include <iomanip>

using namespace std;

#include "algfns.h"
#include "initialsolutiongenerator.h"
#include "display.h"

#endif //hillClimber_H

