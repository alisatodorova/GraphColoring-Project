#ifndef DISPLAY_H
#define DISPLAY_H

#include <fstream>
#include <iostream>
#include <stdlib.h>
#include <vector>
#include <list>
#include <math.h>
#include "hillClimber.h"

void prettyPrintSolution(vector< vector<int> > &candSol);
//Just prints the solution to the screen

void prettyPrintSolution(vector< vector<int> > &candSol, vector< vector<int> > &unplaced);
//The same as above, but also prints the unplaced list

void checkSolution(vector< vector<int> > &candSol, int numItems);
//Takes a complete solution and checks that it represents a feasible colouring.
//Returns error messages if the colouring is wrong/illegal

void readInputFile(ifstream &inStream, int &numNodes, int &numEdges);

#endif //DISPLAY_H
