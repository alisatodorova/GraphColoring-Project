#ifndef PETURB_H
#define PETURB_H

#include "Graph.h"
#include <iostream>
#include <stdlib.h>
#include <iomanip>
#include <vector>

using namespace std;

void doRandomPeturbation(vector<int> &osp, int k, Graph &g);

#endif
